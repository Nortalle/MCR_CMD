package View;

import javax.swing.*;

/**
 * Class used to display the current action
 */
public class Logs {

    private JTextArea textArea1;
    private JPanel main_panel;

    public JPanel getMain_panel() {
        return main_panel;
    }

    public JTextArea getTextArea1() {
        return textArea1;
    }
}
